using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TCC_Tela_Inicial.Views.Home
{
    public class confirmaDadosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
